// 📍 Ruta del archivo: components/games/memorama/MemoramaGame.tsx

"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { MemoramaGameState, MemoramaVariant } from "./types";
import {
  DEFAULT_MEMORAMA_VARIANT,
  MEMORAMA_RESOLVE_MS,
  MEMORAMA_SET_LABELS,
  MEMORAMA_SETS,
  MEMORAMA_STORE_LOCKED_SETS,
  MEMORAMA_TURN_SECONDS,
  areAllPairsMatched,
  createInitialMemoramaState,
  getCardById,
  getTurnTimes,
  getWinnerFromScores,
  isCardVisible,
  normalizeMemoramaVariant,
} from "./utils";

type MemoramaGameProps = {
  roomCode: string;
};

type RoomRow = {
  code: string;
  status: string;
  game_slug: string | null;
  game_variant: string | null;
  room_settings: Record<string, any> | null;
};

type RoomPlayerRow = {
  id: string;
  room_code: string;
  user_id: string | null;
  player_name: string;
  is_host: boolean;
  is_guest: boolean;
  is_ready: boolean;
  created_at: string;
};

const getPlayerKey = (player: RoomPlayerRow) => {
  return player.user_id ?? player.id;
};

export default function MemoramaGame({ roomCode }: MemoramaGameProps) {
  const router = useRouter();
  const supabaseRef = useRef(createClient());
  const supabase = supabaseRef.current;
  const resolveTimerRef = useRef<number | null>(null);
  const lastSoundKeyRef = useRef("");

  const [room, setRoom] = useState<RoomRow | null>(null);
  const [players, setPlayers] = useState<RoomPlayerRow[]>([]);
  const [gameState, setGameState] = useState<MemoramaGameState>(
    createInitialMemoramaState(),
  );
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [nowMs, setNowMs] = useState(Date.now());

  const currentPlayerName = useMemo(() => {
    if (typeof window === "undefined") return "";

    const canonical = localStorage.getItem(`lmf:player:${roomCode}`);

    if (canonical) {
      try {
        const parsed = JSON.parse(canonical);
        if (parsed?.playerName) return String(parsed.playerName);
      } catch {}
    }

    return (
      localStorage.getItem(`la-mesa-player-name-${roomCode}`) ||
      localStorage.getItem(`mesa-player-name-${roomCode}`) ||
      localStorage.getItem("playerName") ||
      ""
    );
  }, [roomCode]);

  const sortedPlayers = useMemo(() => {
    return [...players].sort((a, b) => a.created_at.localeCompare(b.created_at));
  }, [players]);

  const currentPlayer = useMemo(() => {
    return sortedPlayers.find((p) => p.player_name === currentPlayerName) ?? null;
  }, [sortedPlayers, currentPlayerName]);

  const currentPlayerKey = currentPlayer ? getPlayerKey(currentPlayer) : null;
  const isHost = !!currentPlayer?.is_host;

  const isMyTurn =
    !!currentPlayerKey && gameState.currentTurnKey === currentPlayerKey;

  const turnSecondsLeft = useMemo(() => {
    if (gameState.phase !== "playing" || !gameState.turnEndsAt) return 0;

    const diff = new Date(gameState.turnEndsAt).getTime() - nowMs;
    return Math.max(0, Math.ceil(diff / 1000));
  }, [gameState.phase, gameState.turnEndsAt, nowMs]);

  const extractMemoramaState = (
    settings: Record<string, any> | null | undefined,
  ): MemoramaGameState => {
    const saved = settings?.memorama;
    const configuredVariant = normalizeMemoramaVariant(
      settings?.memorama_variant ?? saved?.variant ?? DEFAULT_MEMORAMA_VARIANT,
    );

    if (!saved || saved.phase === undefined) {
      return createInitialMemoramaState(configuredVariant);
    }

    return {
      ...createInitialMemoramaState(configuredVariant),
      ...saved,
      variant: normalizeMemoramaVariant(saved.variant ?? configuredVariant),
      cards: saved.cards ?? [],
      selectedCardIds: saved.selectedCardIds ?? saved.flippedCardIds ?? [],
      matchedCardIds: saved.matchedCardIds ?? [],
      matchedPairOwners: saved.matchedPairOwners ?? {},
      scores: saved.scores ?? {},
      isResolving: saved.isResolving ?? false,
      lastResult: saved.lastResult ?? null,
      turnStartedAt: saved.turnStartedAt ?? null,
      turnEndsAt: saved.turnEndsAt ?? null,
    };
  };

  const updateMemoramaState = useCallback(
    async (updater: (current: MemoramaGameState) => MemoramaGameState) => {
      if (!room) return;

      setSaving(true);

      const currentSettings = room.room_settings ?? {};
      const currentState = extractMemoramaState(currentSettings);
      const nextState = updater(currentState);

      const nextSettings = {
        ...currentSettings,
        memorama_variant: nextState.variant,
        memorama: {
          ...nextState,
          updatedAt: new Date().toISOString(),
        },
      };

      const { error } = await supabase
        .from("rooms")
        .update({ room_settings: nextSettings })
        .eq("code", roomCode);

      if (error) {
        console.error("Error actualizando Memorama:", error);
        alert("No se pudo actualizar la partida.");
      } else {
        setGameState(nextSettings.memorama);
        setRoom((prev) =>
          prev ? { ...prev, room_settings: nextSettings } : prev,
        );
      }

      setSaving(false);
    },
    [room, roomCode, supabase],
  );

  const loadRoom = useCallback(async () => {
    const { data, error } = await supabase
      .from("rooms")
      .select("code, status, game_slug, game_variant, room_settings")
      .eq("code", roomCode)
      .maybeSingle();

    if (error) {
      console.error("Error cargando sala:", error);
      return;
    }

    if (!data) return;

    if (data.status === "closed") {
      router.replace("/");
      return;
    }

    if (data.status === "waiting") {
      router.replace(`/sala/${roomCode}`);
      return;
    }

    setRoom(data as RoomRow);
    setGameState(extractMemoramaState(data.room_settings));
  }, [roomCode, router, supabase]);

  const loadPlayers = useCallback(async () => {
    const { data, error } = await supabase
      .from("room_players")
      .select("id, room_code, user_id, player_name, is_host, is_guest, is_ready, created_at")
      .eq("room_code", roomCode)
      .order("created_at", { ascending: true });

    if (error) {
      console.error("Error cargando jugadores:", error);
      return;
    }

    setPlayers((data ?? []) as RoomPlayerRow[]);
  }, [roomCode, supabase]);

  const getNextPlayer = useCallback(
    (currentTurnKey: string | null) => {
      if (sortedPlayers.length === 0) return null;

      const currentIndex = sortedPlayers.findIndex(
        (player) => getPlayerKey(player) === currentTurnKey,
      );

      if (currentIndex < 0) return sortedPlayers[0];

      return sortedPlayers[(currentIndex + 1) % sortedPlayers.length] ?? sortedPlayers[0];
    },
    [sortedPlayers],
  );

  const playToneSequence = (
    notes: number[],
    type: OscillatorType = "triangle",
    volume = 0.12,
    duration = 0.12,
  ) => {
    try {
      const AudioContextClass =
        window.AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContextClass();

      notes.forEach((frequency, index) => {
        const oscillator = audioContext.createOscillator();
        const gain = audioContext.createGain();
        const startAt = audioContext.currentTime + index * 0.09;

        oscillator.type = type;
        oscillator.frequency.value = frequency;

        gain.gain.setValueAtTime(0.0001, startAt);
        gain.gain.exponentialRampToValueAtTime(volume, startAt + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration);

        oscillator.connect(gain);
        gain.connect(audioContext.destination);

        oscillator.start(startAt);
        oscillator.stop(startAt + duration + 0.04);
      });
    } catch (error) {
      console.error("No se pudo reproducir sonido de Memorama:", error);
    }
  };

  const playFlipSound = () => playToneSequence([392, 523.25], "sine", 0.08, 0.1);
  const playMatchSound = () => playToneSequence([523.25, 659.25, 783.99], "triangle", 0.14, 0.16);
  const playMissSound = () => playToneSequence([220, 164.81], "sawtooth", 0.08, 0.12);
  const playTimeoutSound = () => playToneSequence([196, 146.83], "square", 0.06, 0.1);
  const playWinSound = () => playToneSequence([523.25, 659.25, 783.99, 1046.5], "triangle", 0.18, 0.22);

  const startGame = async () => {
    if (sortedPlayers.length < 2) {
      alert("Memorama necesita 2 jugadores.");
      return;
    }

    const configuredVariant = normalizeMemoramaVariant(
      room?.room_settings?.memorama_variant ?? DEFAULT_MEMORAMA_VARIANT,
    );

    const firstPlayer = sortedPlayers[Math.floor(Math.random() * sortedPlayers.length)];
    const firstKey = getPlayerKey(firstPlayer);
    const turnTimes = getTurnTimes();

    await updateMemoramaState(() => {
      const scores = sortedPlayers.reduce<MemoramaGameState["scores"]>(
        (acc, player) => {
          const key = getPlayerKey(player);

          acc[key] = {
            playerKey: key,
            playerName: player.player_name,
            pairs: 0,
          };

          return acc;
        },
        {},
      );

      return {
        ...createInitialMemoramaState(configuredVariant),
        phase: "playing",
        currentTurnKey: firstKey,
        currentTurnName: firstPlayer.player_name,
        scores,
        ...turnTimes,
      };
    });
  };

  const resolveSelectedCards = useCallback(async () => {
    await updateMemoramaState((current) => {
      if (current.phase !== "playing") return current;
      if (!current.isResolving) return current;
      if (current.selectedCardIds.length !== 2) return current;

      const firstCard = getCardById(current.cards, current.selectedCardIds[0]);
      const secondCard = getCardById(current.cards, current.selectedCardIds[1]);

      if (!firstCard || !secondCard || !current.currentTurnKey) {
        return {
          ...current,
          selectedCardIds: [],
          isResolving: false,
          lastResult: null,
          ...getTurnTimes(),
        };
      }

      const isMatch = firstCard.pairId === secondCard.pairId;

      if (isMatch) {
        const nextMatchedCardIds = [
          ...current.matchedCardIds,
          firstCard.id,
          secondCard.id,
        ];

        const currentScore = current.scores[current.currentTurnKey] ?? {
          playerKey: current.currentTurnKey,
          playerName: current.currentTurnName ?? "Jugador",
          pairs: 0,
        };

        const nextScores = {
          ...current.scores,
          [current.currentTurnKey]: {
            ...currentScore,
            pairs: currentScore.pairs + 1,
          },
        };

        const finished = areAllPairsMatched(current.cards, nextMatchedCardIds);
        const winner = finished
          ? getWinnerFromScores(nextScores)
          : { winnerKey: null, winnerName: null };

        return {
          ...current,
          phase: finished ? "finished" : current.phase,
          selectedCardIds: [],
          matchedCardIds: nextMatchedCardIds,
          matchedPairOwners: {
            ...current.matchedPairOwners,
            [firstCard.pairId]: current.currentTurnKey,
          },
          scores: nextScores,
          isResolving: false,
          lastResult: "match",
          winnerKey: winner.winnerKey,
          winnerName: winner.winnerName,
          turnStartedAt: finished ? null : getTurnTimes().turnStartedAt,
          turnEndsAt: finished ? null : getTurnTimes().turnEndsAt,
        };
      }

      const nextPlayer = getNextPlayer(current.currentTurnKey);
      const nextPlayerKey = nextPlayer ? getPlayerKey(nextPlayer) : current.currentTurnKey;

      return {
        ...current,
        selectedCardIds: [],
        isResolving: false,
        lastResult: "miss",
        currentTurnKey: nextPlayerKey,
        currentTurnName: nextPlayer?.player_name ?? current.currentTurnName,
        ...getTurnTimes(),
      };
    });
  }, [getNextPlayer, updateMemoramaState]);

  const handleTimeoutTurn = useCallback(async () => {
    await updateMemoramaState((current) => {
      if (current.phase !== "playing") return current;
      if (current.isResolving) return current;
      if (!current.turnEndsAt) return current;

      const hasExpired = Date.now() >= new Date(current.turnEndsAt).getTime();
      if (!hasExpired) return current;

      const nextPlayer = getNextPlayer(current.currentTurnKey);
      const nextPlayerKey = nextPlayer ? getPlayerKey(nextPlayer) : current.currentTurnKey;

      return {
        ...current,
        selectedCardIds: [],
        isResolving: false,
        lastResult: "timeout",
        currentTurnKey: nextPlayerKey,
        currentTurnName: nextPlayer?.player_name ?? current.currentTurnName,
        ...getTurnTimes(),
      };
    });
  }, [getNextPlayer, updateMemoramaState]);

  const handleCardClick = async (cardId: string) => {
    if (!currentPlayer || !currentPlayerKey) return;
    if (gameState.phase !== "playing") return;

    if (!isMyTurn) {
      alert("Todavía no es tu turno.");
      return;
    }

    if (saving || gameState.isResolving) return;

    playFlipSound();

    await updateMemoramaState((current) => {
      if (current.phase !== "playing") return current;
      if (current.currentTurnKey !== currentPlayerKey) return current;
      if (current.isResolving) return current;
      if (current.selectedCardIds.length >= 2) return current;

      const selectedCard = getCardById(current.cards, cardId);

      if (!selectedCard) return current;
      if (current.matchedCardIds.includes(selectedCard.id)) return current;
      if (current.selectedCardIds.includes(selectedCard.id)) return current;

      const nextSelectedCardIds = [...current.selectedCardIds, selectedCard.id];

      return {
        ...current,
        selectedCardIds: nextSelectedCardIds,
        isResolving: nextSelectedCardIds.length === 2,
        lastResult: null,
        turnEndsAt: nextSelectedCardIds.length === 2 ? null : current.turnEndsAt,
      };
    });
  };

  const handleRematch = async () => {
    await startGame();
  };

  const handleBackToSala = async () => {
    const ok = window.confirm("¿Quieres volver a sala? Todos regresarán a la sala.");
    if (!ok) return;

    const { error } = await supabase
      .from("rooms")
      .update({ status: "waiting" })
      .eq("code", roomCode);

    if (error) {
      console.error("Error volviendo a sala:", error);
      alert("No se pudo volver a sala.");
      return;
    }

    router.replace(`/sala/${roomCode}`);
  };

  const handleCloseRoom = async () => {
    if (!isHost) return;

    const ok = window.confirm("¿Seguro que quieres terminar la sala?");
    if (!ok) return;

    const { error } = await supabase
      .from("rooms")
      .update({ status: "closed" })
      .eq("code", roomCode);

    if (error) {
      console.error("Error cerrando sala:", error);
      alert("No se pudo cerrar la sala.");
      return;
    }

    await supabase.from("room_players").delete().eq("room_code", roomCode);
    router.replace("/");
  };

  useEffect(() => {
    const boot = async () => {
      setLoading(true);
      await Promise.all([loadRoom(), loadPlayers()]);
      setLoading(false);
    };

    void boot();
  }, [loadRoom, loadPlayers]);

  useEffect(() => {
    const channel = supabase
      .channel(`memorama-${roomCode}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "rooms",
          filter: `code=eq.${roomCode}`,
        },
        async () => {
          await loadRoom();
        },
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "room_players",
          filter: `room_code=eq.${roomCode}`,
        },
        async () => {
          await loadPlayers();
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [supabase, roomCode, loadRoom, loadPlayers]);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setNowMs(Date.now());
    }, 250);

    return () => window.clearInterval(interval);
  }, []);

  useEffect(() => {
    if (gameState.phase !== "playing") return;
    if (!gameState.isResolving) return;
    if (gameState.selectedCardIds.length !== 2) return;

    if (resolveTimerRef.current) {
      window.clearTimeout(resolveTimerRef.current);
    }

    resolveTimerRef.current = window.setTimeout(() => {
      void resolveSelectedCards();
    }, MEMORAMA_RESOLVE_MS);

    return () => {
      if (resolveTimerRef.current) {
        window.clearTimeout(resolveTimerRef.current);
        resolveTimerRef.current = null;
      }
    };
  }, [
    gameState.phase,
    gameState.isResolving,
    gameState.selectedCardIds,
    resolveSelectedCards,
  ]);

  useEffect(() => {
    if (gameState.phase !== "playing") return;
    if (gameState.isResolving) return;
    if (!gameState.turnEndsAt) return;
    if (turnSecondsLeft > 0) return;

    void handleTimeoutTurn();
  }, [
    gameState.phase,
    gameState.isResolving,
    gameState.turnEndsAt,
    turnSecondsLeft,
    handleTimeoutTurn,
  ]);

  useEffect(() => {
    const soundKey = `${gameState.updatedAt}-${gameState.lastResult}-${gameState.phase}`;

    if (soundKey === lastSoundKeyRef.current) return;

    lastSoundKeyRef.current = soundKey;

    if (gameState.phase === "finished") {
      playWinSound();
      return;
    }

    if (gameState.lastResult === "match") playMatchSound();
    if (gameState.lastResult === "miss") playMissSound();
    if (gameState.lastResult === "timeout") playTimeoutSound();
  }, [gameState.updatedAt, gameState.lastResult, gameState.phase]);

  if (loading) {
    return (
      <main className="min-h-screen bg-black px-6 py-10 text-white">
        <div className="mx-auto max-w-5xl rounded-[32px] border border-white/10 bg-zinc-950 p-8 text-center">
          <p className="text-2xl font-black">Cargando Memorama...</p>
        </div>
      </main>
    );
  }

  const variantLabel = MEMORAMA_SET_LABELS[gameState.variant.set] ?? "Clásico";
  const variantPreview = MEMORAMA_SETS[gameState.variant.set]?.slice(0, 6) ?? [];
  const isPremiumSet = MEMORAMA_STORE_LOCKED_SETS.includes(gameState.variant.set);

  return (
    <main className="min-h-screen bg-black px-4 py-6 text-white md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <section className="rounded-[32px] border border-orange-500/20 bg-zinc-950/95 p-6 shadow-[0_0_40px_rgba(249,115,22,0.06)]">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.22em] text-orange-300/80">
                La Mesa Familiar
              </p>

              <h1 className="mt-2 text-3xl font-black md:text-4xl">
                🧠 Memorama
              </h1>

              <p className="mt-2 text-sm text-white/60">
                Variante:{" "}
                <span className="font-bold text-orange-300">{variantLabel}</span>
                {" · "}
                {gameState.variant.pairs} pares
                {isPremiumSet ? " · Premium preparado para tienda" : ""}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleBackToSala}
                className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-bold text-white hover:bg-white/10"
              >
                Volver a sala
              </button>

              {isHost && (
                <button
                  type="button"
                  onClick={handleCloseRoom}
                  className="rounded-2xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm font-bold text-red-200 hover:bg-red-500/20"
                >
                  Terminar sala
                </button>
              )}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-3">
            {variantPreview.map((emoji, index) => (
              <span
                key={`${emoji}-${index}`}
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-black/30 text-xl"
              >
                {emoji}
              </span>
            ))}
          </div>
        </section>

        <section className="grid gap-5 xl:grid-cols-[340px_1fr]">
          <aside className="space-y-5">
            <div className="rounded-[28px] border border-white/10 bg-zinc-950/90 p-5">
              <h2 className="text-xl font-black">🏆 Marcador</h2>

              <div className="mt-4 space-y-3">
                {sortedPlayers.map((player) => {
                  const key = getPlayerKey(player);
                  const score = gameState.scores[key]?.pairs ?? 0;

                  return (
                    <div
                      key={player.id}
                      className={
                        gameState.currentTurnKey === key
                          ? "rounded-2xl border border-orange-400 bg-orange-500/15 p-4 shadow-[0_0_22px_rgba(249,115,22,0.14)]"
                          : "rounded-2xl border border-white/10 bg-white/[0.03] p-4"
                      }
                    >
                      <p className="font-black">
                        {player.player_name} {key === currentPlayerKey ? "(Tú)" : ""}
                      </p>

                      <p className="mt-1 text-sm font-bold text-white/60">
                        Parejas:{" "}
                        <span className="text-orange-300">{score}</span>
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="rounded-[28px] border border-white/10 bg-zinc-950/90 p-5">
              <h2 className="text-xl font-black">🎮 Estado</h2>

              {gameState.phase === "waiting" && (
                <div className="mt-4 space-y-3">
                  <p className="rounded-2xl border border-yellow-500/20 bg-yellow-500/10 p-4 text-sm text-yellow-100">
                    Listo para iniciar Memorama.
                  </p>

                  {isHost ? (
                    <button
                      type="button"
                      onClick={startGame}
                      disabled={saving || sortedPlayers.length < 2}
                      className="w-full rounded-2xl bg-orange-500 px-4 py-3 font-black text-black hover:bg-orange-400 disabled:opacity-50"
                    >
                      Iniciar partida
                    </button>
                  ) : (
                    <p className="text-sm text-white/50">
                      Esperando que el host inicie la partida.
                    </p>
                  )}
                </div>
              )}

              {gameState.phase === "playing" && (
                <div
                  className={
                    isMyTurn
                      ? "mt-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4"
                      : "mt-4 rounded-2xl border border-purple-500/20 bg-purple-500/10 p-4"
                  }
                >
                  <p className="text-sm font-bold text-white/60">Turno actual</p>
                  <p className="mt-1 text-2xl font-black">
                    {gameState.currentTurnName ?? "Jugador"}
                  </p>

                  <div className="mt-3 rounded-2xl border border-white/10 bg-black/30 p-3">
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-white/45">
                      Tiempo
                    </p>
                    <p className="mt-1 text-4xl font-black text-orange-300">
                      {turnSecondsLeft}s
                    </p>
                  </div>

                  <p className="mt-2 text-sm text-white/60">
                    {gameState.isResolving
                      ? "Resolviendo selección..."
                      : isMyTurn
                        ? `Elige 2 cartas antes de ${MEMORAMA_TURN_SECONDS} segundos.`
                        : "Espera tu turno."}
                  </p>

                  {gameState.lastResult === "match" && (
                    <p className="mt-2 text-sm font-bold text-emerald-300">
                      ✅ Pareja encontrada.
                    </p>
                  )}

                  {gameState.lastResult === "miss" && (
                    <p className="mt-2 text-sm font-bold text-red-300">
                      ❌ No era pareja.
                    </p>
                  )}

                  {gameState.lastResult === "timeout" && (
                    <p className="mt-2 text-sm font-bold text-yellow-300">
                      ⏳ Tiempo agotado.
                    </p>
                  )}
                </div>
              )}

              {gameState.phase === "finished" && (
                <div className="mt-4 rounded-2xl border border-orange-500/30 bg-orange-500/10 p-4">
                  <p className="text-sm font-bold uppercase tracking-[0.2em] text-orange-300">
                    Partida terminada
                  </p>

                  <p className="mt-2 text-3xl font-black">
                    {gameState.winnerName === "Empate"
                      ? "🤝 Empate"
                      : `🏆 ${gameState.winnerName}`}
                  </p>

                  {isHost && (
                    <button
                      type="button"
                      onClick={handleRematch}
                      className="mt-4 w-full rounded-2xl bg-orange-500 px-4 py-3 font-black text-black hover:bg-orange-400"
                    >
                      Revancha
                    </button>
                  )}
                </div>
              )}
            </div>
          </aside>

          <section className="rounded-[32px] border border-white/10 bg-zinc-950/90 p-4 md:p-6">
            <div className={gameState.variant.pairs > 8 ? "grid grid-cols-4 gap-3 lg:grid-cols-6" : "grid grid-cols-4 gap-3"}>
              {gameState.cards.map((card) => {
                const visible = isCardVisible(
                  card,
                  gameState.selectedCardIds,
                  gameState.matchedCardIds,
                );

                const matched = gameState.matchedCardIds.includes(card.id);
                const selected = gameState.selectedCardIds.includes(card.id);
                const ownerKey = gameState.matchedPairOwners?.[card.pairId] ?? null;
                const isMineMatchedPair = ownerKey === currentPlayerKey;

                const resolvingSelected =
                  selected && gameState.isResolving && !matched;

                const disabled =
                  saving ||
                  gameState.phase !== "playing" ||
                  !isMyTurn ||
                  gameState.isResolving ||
                  visible;

                return (
                  <button
                    key={card.id}
                    type="button"
                    disabled={disabled}
                    onClick={() => void handleCardClick(card.id)}
                    className={
                      matched
                        ? isMineMatchedPair
                          ? "aspect-square rounded-3xl border border-emerald-400/50 bg-emerald-500/20 text-5xl shadow-[0_0_28px_rgba(16,185,129,0.18)]"
                          : "aspect-square rounded-3xl border border-cyan-400/50 bg-cyan-500/20 text-5xl shadow-[0_0_28px_rgba(34,211,238,0.18)]"
                        : resolvingSelected
                          ? "aspect-square rounded-3xl border border-orange-400/60 bg-orange-500/20 text-5xl shadow-[0_0_28px_rgba(249,115,22,0.18)]"
                          : visible
                            ? "aspect-square rounded-3xl border border-orange-400/50 bg-orange-500/20 text-5xl shadow-[0_0_28px_rgba(249,115,22,0.18)]"
                            : "aspect-square rounded-3xl border border-white/10 bg-white/[0.04] text-4xl transition hover:scale-[1.03] hover:border-orange-400/50 hover:bg-orange-500/10 disabled:hover:scale-100"
                    }
                  >
                    <span className="flex h-full w-full items-center justify-center">
                      {visible ? card.emoji : "❔"}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        </section>
      </div>
    </main>
  );
}
